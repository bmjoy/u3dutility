<?php get_header();

	while(have_posts()): the_post();
	
	  //GETTING META VALUES...
	  $meta_set = get_post_meta($post->ID, '_dt_post_settings', true);
	  $page_layout = !empty($meta_set['layout']) ? $meta_set['layout'] : 'content-full-width'; ?>
	
	  <div class="banner"></div>
      <!-- Page Section Starts here -->
      <section id="post-<?php the_ID(); ?>" <?php post_class('content inner-page'); ?>>
          <div class="main-title">
              <div class="container">
                  <h1><?php the_title(); ?></h1>
              </div>
          </div>
          <div class="content-main">                
              <div class="container">
              
                  <!-- Primary -->
                  <div id="primary" class="<?php echo $page_layout; ?>">
                      <div class="blog-post-single"><?php
						  //POST TOP CODE...
						  if(mytheme_option('integration', 'enable-single-post-top-code') != '') echo stripslashes(mytheme_option('integration', 'single-post-top-code')); ?>
                          
                          <header class="post-meta<?php if(is_sticky()) echo " sticky"; ?>"><?php
						  	  if(isset($meta_set['disable-date-info']) == ""): ?>
                                  <div class="date">
                                      <span class="day"><?php echo get_the_date('d'); ?></span>
                                      <span class="date-group"><?php echo get_the_date('M'); ?><br><?php echo get_the_date('Y'); ?></span>
                                  </div><?php
							  endif;
							  if(isset($meta_set['disable-comment-info']) == ""):
							  	  comments_popup_link('<span class="icon-comment"><span>0</span></span>comments','<span class="icon-comment"><span>1</span></span>comment','<span class="icon-comment"><span>%</span></span>comments', 'comments', 'comments off');
							  endif;
							  if(is_sticky()) echo '<span class="featured-post">'.__("Featured", "iamd_text_domain").'</span>'; ?>
                          </header><?php
						  
                          if(has_post_thumbnail() && isset($meta_set['disable-featured-image']) != 'true'):
						  	  $feature_image = 'custom-thumb';
							  if($page_layout != 'content-full-width') $feature_image = 'custom-thumb'.'-sidebar'; ?>
                              <div class="post-thumb">
                                  <?php $attr = array('title' => get_the_title()); the_post_thumbnail($feature_image, $attr); ?>
                              </div><?php
						  endif; ?>
                          
                          <div class="entry-details">
                              <h2><?php the_title(); ?></h2>
                              <div class="entry-meta"><?php
							  
	                              if(isset($meta_set['disable-author-info']) == ""):
								  	  _e('Posted by', 'iamd_text_domain'); ?> : <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author_meta('display_name'); ?></a><?php
								  endif;
								  if(isset($meta_set['disable-category-info']) == "" && count(get_the_category())):
									  _e(' Categories', 'iamd_text_domain'); ?> : <?php the_category(', ');
								  endif;
								  if(isset($meta_set['disable-tag-info']) == ""):
								  	  the_tags(__(' and Tags : ', 'iamd_text_domain'), ', ', '');
								  endif; ?>
                                  
                              </div><?php
							  the_content();
							  wp_link_pages(array('before' => '<div class="page-link"><strong>'.__('Pages:', 'iamd_text_domain').'</strong> ', 'after' => '</div>', 'next_or_number' => 'number'));
							  edit_post_link(__('Edit', 'iamd_text_domain'), '<span class="edit-link">', '</span>' );
							  echo '<div class="social-bookmark">';
								show_fblike('post'); show_googleplus('post'); show_twitter('post'); show_stumbleupon('post'); show_linkedin('post'); show_delicious('post'); show_pintrest('post'); show_digg('post');
							  echo '</div>';
							  mytheme_social_bookmarks('sb-post');
							  if(mytheme_option('integration', 'enable-single-page-bottom-code') != '') echo stripslashes(mytheme_option('integration', 'single-page-bottom-code')); ?>
                          </div>
                          
	                      <?php if(mytheme_option('general', 'disable-post-comment') != true && (isset($meta_set['disable-comment']) == "")) comments_template('', true); ?>
                      </div>
                  </div><!-- Primary -->
                  
                  <!-- Secondary -->
				  <?php if($page_layout != 'content-full-width' && $page_layout == 'with-left-sidebar'): ?>
                      <div id="secondary" class="left-sidebar"><?php get_sidebar(); ?></div>
                  <?php elseif($page_layout != 'content-full-width' && $page_layout == 'with-right-sidebar'): ?>    
                      <div id="secondary"><?php get_sidebar(); ?></div>
                  <?php endif; ?><!-- Secondary -->
              
              </div>                                
          </div>
      </section><!-- Page Section Ends here -->
      
	<?php endwhile; ?>      

<?php get_footer(); ?>