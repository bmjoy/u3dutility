<?php get_header();

	  $page_layout = mytheme_option('specialty', 'search-layout'); ?>
	
	  <div class="banner"></div>
      <!-- Page Section Starts here -->
      <section id="post-<?php the_ID(); ?>" <?php post_class('content inner-page'); ?>>
	      <?php if(!is_front_page() and !is_home()): ?>
              <div class="main-title">
                  <div class="container">
                      <h1><?php printf(__('Search Results for : %s', 'iamd_text_domain'), get_search_query()); ?></h1>
                  </div>
              </div>
		  <?php endif; ?>              
          <div class="content-main">                
              <div class="container">
              
                  <!-- Primary -->
                  <div id="primary" class="<?php echo $page_layout; ?>"><?php
					  //PERFORMING QUERY...
					  global $wp_query;
					  
					  if(have_posts()): $i = 1;
					    while(have_posts()): the_post(); ?>
                      	  <article id="post-<?php the_ID(); ?>" <?php post_class('blog-post'); ?>>
                              <header class="post-meta<?php if(is_sticky()) echo " sticky"; ?>">
                                    <div class="date">
                                        <span class="day"><?php echo get_the_date('d'); ?></span>
                                        <span class="date-group"><?php echo get_the_date('M'); ?><br><?php echo get_the_date('Y'); ?></span>
                                    </div><?php
                                    comments_popup_link('<span class="icon-comment"><span>0</span></span>comments','<span class="icon-comment"><span>1</span></span>comment','<span class="icon-comment"><span>%</span></span>comments', 'comments', 'comments off'); 
									if(is_sticky()) echo '<span class="featured-post">'.__("Featured", "iamd_text_domain").'</span>'; ?>
                              </header><?php
                              
                              if(has_post_thumbnail()):
                                  $feature_image = 'custom-thumb';
                                  if($page_layout != 'content-full-width') $feature_image = 'custom-thumb'.'-sidebar'; ?>
                                  <div class="post-thumb">
                                      <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php $attr = array('title' => get_the_title()); the_post_thumbnail($feature_image, $attr); ?></a>
                                  </div><?php
                              endif; ?>
                              
                              <div class="entry-details">
                                  <h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                                  <div class="entry-meta"><?php
                                    _e('Posted by', 'iamd_text_domain'); ?> : <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author_meta('display_name'); ?></a><?php
                                    if(count(get_the_category())) { _e(' Categories', 'iamd_text_domain'); ?> : <?php the_category(', '); }
                                    the_tags(__(' and Tags : ', 'iamd_text_domain'), ', ', ''); ?>                                  
                                  </div>
                                  <?php the_excerpt(); ?>
                              </div>
                          </article>
						  <div class="margin40"></div><?php
						endwhile;
						if($wp_query->max_num_pages > 1): ?>
							<div class="pagination">
								<ul><?php if(function_exists("my_pagination")) echo my_pagination("", $wp_query->max_num_pages, $wp_query); ?></ul>
							</div><?php
						 endif;
						 wp_reset_query($wp_query);
						else: ?>
							<h2><?php _e('Nothing Found.', 'iamd_text_domain'); ?></h2>
							<p><?php _e('Apologies, but no results were found for the requested archive.', 'iamd_text_domain'); ?></p><?php
						endif; ?>
                  </div><!-- Primary -->
                  
                  <!-- Secondary -->
				  <?php if($page_layout != 'content-full-width' && $page_layout == 'with-left-sidebar'): ?>
                      <div id="secondary" class="left-sidebar"><?php get_sidebar(); ?></div>
                  <?php elseif($page_layout != 'content-full-width' && $page_layout == 'with-right-sidebar'): ?>    
                      <div id="secondary"><?php get_sidebar(); ?></div>
                  <?php endif; ?><!-- Secondary -->
              
              </div>                                
          </div>
      </section><!-- Page Section Ends here -->
      
<?php get_footer(); ?>