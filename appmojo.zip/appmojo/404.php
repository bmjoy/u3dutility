<?php get_header();

	  //GETTING META VALUES...
	  $page_layout = mytheme_option('specialty', '404-layout'); ?>
      
	  <div class="banner"></div>	
      <!-- Page Section Starts here -->
      <section id="not-found" class="content inner-page">
          <div class="main-title">
              <div class="container">
                  <h1><?php _e('404 - Not Found', 'iamd_text_domain'); ?></h1>
              </div>
          </div>
          <div class="content-main">                
              <div class="container">
              
                  <!-- Primary -->
                  <div id="primary" class="<?php echo $page_layout; ?>">
                  	  <div class="error-404 aligncenter"><?php
						echo stripcslashes(mytheme_option('specialty','404-message'));
						get_search_form(); ?>
                      </div>
                  </div><!-- Primary -->
                  
                  <!-- Secondary -->
				  <?php if($page_layout != 'content-full-width' && $page_layout == 'with-left-sidebar'): ?>
                      <div id="secondary" class="left-sidebar"><?php get_sidebar(); ?></div>
                  <?php elseif($page_layout != 'content-full-width' && $page_layout == 'with-right-sidebar'): ?>    
                      <div id="secondary"><?php get_sidebar(); ?></div>
                  <?php endif; ?><!-- Secondary -->
              
              </div>                                
          </div>
      </section><!-- Page Section Ends here -->
      
<?php get_footer(); ?>