                <footer>
					<?php if(mytheme_option('general', 'show-footer')): ?>
                    	<div class="footer-widgets">
							<div class="container">
								<?php show_footer_widgetarea(mytheme_option('general','footer-columns')); ?>
							</div>
						</div>
					<?php endif; ?>
                    
					<?php if(mytheme_option('general','show-supportsection') == 'on'): ?>
                        <div class="support">
							<div class="container">
								<?php if(mytheme_option('general','support-image') != ''): ?>
                                    <figure>
                                        <img src="<?php echo mytheme_option('general','support-image'); ?>" alt="" title="">
                                    </figure>
                                <?php endif;
                                if(mytheme_option('general','support-text') != ''): ?>
                                    <div class="support-info">
                                        <?php echo stripslashes(mytheme_option('general','support-text')); ?>
                                    </div><?php
                                endif;
                                if(mytheme_option('general','support-link') != ''): ?>
                                    <a href="<?php echo mytheme_option('general','support-link'); ?>" class="dt-sc-button medium ico"><i class="icon-comments"></i><?php _e('Live Chat Support', 'iamd_text_domain'); ?></a>
                                <?php endif; ?>
                            </div>    
                        </div>
                    <?php endif; ?>
                    
                    <div class="copyright">
                        <div class="container">
                        	<?php if(mytheme_option('general','show-copyrighttext') && mytheme_option('general','copyright-text') != ''): ?>
	                            <p><?php echo mytheme_option('general','copyright-text'); ?></p>
                            <?php endif;
								  if(mytheme_option('general','show-sociables') == 'on'):
									echo dt_social_icons();
								  endif; ?>
                        </div>
                    </div>
                </footer>
			</div><!-- Main div End -->
		</div><!-- Inner Wrapper End -->
    </div><!-- Wrapper End -->
    
<?php do_action('load_footer_styles_scripts'); ?>
<?php if(mytheme_option('integration', 'enable-body-code') != '') echo stripslashes(mytheme_option('integration', 'body-code'));
wp_footer(); ?>
</body>
</html>