<?php
	//PERFORMING BLOG POST LAYOUT...
	$meta_set = get_post_meta($post->ID, '_tpl_default_settings', true);
	$page_layout = !empty($meta_set['layout']) ? $meta_set['layout'] : 'content-full-width';
	$post_layout = 'one-column';
	
	$article_class = "";
	$feature_image = "";
	$column = "";
	
	//POST LAYOUT CHECK...
	if($post_layout == "one-column") {
		$article_class = "blog-post";
		$feature_image = "custom-thumb";
	}
	
	//PAGE LAYOUT CHECK...
	if($page_layout != "content-full-width") {
		$feature_image = $feature_image."-sidebar";
	}
	
	//POST VALUES....
	$limit = $meta_set['blog-post-per-page'];
	$cats  = $meta_set['blog-post-exclude-categories'];
	
	$cats = array_filter(array_unique($cats));
	
	if(count($cats) == 0) array_push($cats, '0');
	
	//PERFORMING QUERY...
	if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
	elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
	else { $paged = 1; }
	
	//PERFORMING QUERY...	
	$args = array('post_type' => 'post', 'paged' => $paged, 'posts_per_page' => $limit, 'category__not_in' => $cats);
	$wp_query = new WP_Query($args);
	
	if($wp_query->have_posts()): $i = 1;
	  while($wp_query->have_posts()): $wp_query->the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class('blog-post'); ?>>
			<header class="post-meta<?php if(is_sticky()) echo " sticky"; ?>"><?php
				if(isset($meta_set['disable-date-info']) == ""): ?>
                    <div class="date">
                        <span class="day"><?php echo get_the_date('d'); ?></span>
                        <span class="date-group"><?php echo get_the_date('M'); ?><br><?php echo get_the_date('Y'); ?></span>
                    </div><?php
				endif;
				if(isset($meta_set['disable-comment-info']) == ""):
				  comments_popup_link('<span class="icon-comment"><span>0</span></span>comments','<span class="icon-comment"><span>1</span></span>comment','<span class="icon-comment"><span>%</span></span>comments', 'comments', 'comments off'); 
				endif;				  
				if(is_sticky()) echo '<span class="featured-post">'.__("Featured", "iamd_text_domain").'</span>'; ?>
			</header><?php
			
			if(has_post_thumbnail()): ?>
				<div class="post-thumb">
					<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php $attr = array('title' => get_the_title()); the_post_thumbnail($feature_image, $attr); ?></a>
				</div><?php
			endif; ?>
			
			<div class="entry-details">
				<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
				<div class="entry-meta"><?php
					if(isset($meta_set['disable-author-info']) == ""):							  
						_e('Posted by', 'iamd_text_domain'); ?> : <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author_meta('display_name'); ?></a><?php
					endif;
					if(isset($meta_set['disable-category-info']) == "" && count(get_the_category())):
					  	_e(' Categories', 'iamd_text_domain'); ?> : <?php the_category(', ');
					endif;
					if(isset($meta_set['disable-tag-info']) == ""):						
					  the_tags(__(' and Tags : ', 'iamd_text_domain'), ', ', '');
					endif; ?>
				</div>
				<?php 
				if(isset($meta_set['blog-post-excerpt']) != "")
					echo mytheme_excerpt($meta_set['blog-post-excerpt-length']); ?>
			</div>
		</article>
		<div class="margin40"></div><?php
	  endwhile;
	  if($wp_query->max_num_pages > 1): ?>
		  <div class="pagination">
			  <ul><?php if(function_exists("my_pagination")) echo my_pagination("", $wp_query->max_num_pages, $wp_query); ?></ul>
		  </div><?php
	   endif;
	   wp_reset_query($wp_query);
	  else: ?>
		  <h2><?php _e('Nothing Found.', 'iamd_text_domain'); ?></h2>
		  <p><?php _e('Apologies, but no results were found for the requested archive.', 'iamd_text_domain'); ?></p><?php
	  endif; ?>