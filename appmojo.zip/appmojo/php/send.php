<?php
if(!$_POST) exit;

    $to 	  = $_POST['hidadmin_email']; #Replace your email id...
	$name	  = $_POST['txtname'];
	$email    = $_POST['txtemail'];
	$phone    = $_POST['txtphone'];
	$subject  = $_POST['hidsubject'];
    $comment  = $_POST['txtmessage'];
        
	if(get_magic_quotes_gpc()) { $comment = stripslashes($comment); }

	 $e_subject = 'You\'ve been contacted by ' . $name . '.';

	 $msg  = "You have been contacted by $name with regards to $subject.\r\n\n";
	 $msg .= "$comment\r\n\n";
	 $msg .= "You can contact $name via email, $email.\r\n\n";
	 $msg .= "-------------------------------------------------------------------------------------------\r\n";
								
	 if(@mail($to, $e_subject, $msg, "From: $email\r\nReturn-Path: $email\r\n"))
	 {
		 echo "<span class='success-msg'>".$_POST['hidsuccess_msg']."</span>";
	 }
	 else
	 {
		 echo "<span class='error-msg'>".$_POST['hiderror_msg']."</span>";
	 }
?>