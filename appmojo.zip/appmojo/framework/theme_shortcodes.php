<?php
//Call to action box...
if(!function_exists('fun_calltoaction')) {
	
	function fun_calltoaction($atts, $content = null) {
		extract(shortcode_atts(array(
			'animation' => '',								 
			'delay' => '300'
		), $atts));
		
		$out = '';
		if($animation != NULL)
			$out .= '<div class="aligncenter welcome animate" data-animation="'.$animation.'" data-delay="'.$delay.'">';
		else
			$out .= '<div class="aligncenter welcome">';
			
		$out .= do_shortcode($content);
		$out .= '</div>';
		
		return $out;
	}
	add_shortcode('call_to_action', 'fun_calltoaction');
}

//Theme services boxes...
if(!function_exists('fun_themeservice')) {

	function fun_themeservice($atts, $content = null) {
		extract(shortcode_atts(array(
			'animation' => '',								 
			'delay' => '300',
			'icon' => 'icon-laptop',
			'title'	=>	''
		), $atts));
		
		$out = '';

		$out .= '<div class="service">';
			if($animation != NULL) $out .= '<i class="'.$icon.' animate" data-animation="'.$animation.'" data-delay="'.$delay.'"></i>';	
			else $out .= '<i class="'.$icon.'"></i>';	
		
			$out .= '<div class="margin20"></div>';
			
			if($title != NULL) $out .= '<h4>'.$title.'</h4>';
			$out .= '<p>'.do_shortcode($content).'</p>';
			
		$out .= '</div>';
		
		return $out;
	}
	add_shortcode('theme_service', 'fun_themeservice');
}

//Theme mergin values...
if(!function_exists('fun_thememargin')) {
	
	function fun_thememargin($atts, $content = null) {
		extract(shortcode_atts(array(
			'value' => '5'
		), $atts));
		
		$out = '<div class="margin'.$value.'"></div>';
		
		return $out;
	}
	add_shortcode('dt_margin', 'fun_thememargin');
}

//Animated Div...
if(!function_exists('fun_themeanimate')) {
	
	function fun_themeanimate($atts, $content = null) {
		extract(shortcode_atts(array(
			'animation' => 'fadeIn',
			'delay' => '300',
		), $atts));

		$out = '';
		
		$out .= '<div class="animate" data-animation="'.$animation.'" data-delay="'.$delay.'">';
			$out .= do_shortcode($content);
		$out .= '</div>';
		
		return $out;
	}
	add_shortcode('dt_animate', 'fun_themeanimate');
}

//Custom Theme services boxes...
if(!function_exists('fun_customthemeservice')) {

	function fun_customthemeservice($atts, $content = null) {
		extract(shortcode_atts(array(
			'animation' => '',								 
			'delay' => '300',
			'icon' => 'icon-bulb',
			'title'	=>	''
		), $atts));
		
		$out = '';

		$out .= '<div class="custom-services">';
			if($animation != NULL) $out .= '<span class="'.$icon.' animate" data-animation="'.$animation.'" data-delay="'.$delay.'"></span>';	
			else $out .= '<span class="'.$icon.'"></span>';
		
			if($title != NULL) $out .= '<h3>'.$title.'</h3>';
			$out .= '<p>'.do_shortcode($content).'</p>';
			
		$out .= '</div>';
		
		return $out;
	}
	add_shortcode('theme_custom_service', 'fun_customthemeservice');
}

//Custom Theme services boxes...
if(!function_exists('fun_bordertitle')) {

	function fun_bordertitle($atts, $content = null) {
		extract(shortcode_atts(array(
			'tag' => 'h2'
		), $atts));
		
		$out = '';
		
		$out .= '<'.$tag.' class="border-title">'.do_shortcode($content).'<span></span></'.$tag.'>';
		
		return $out;
	}
	add_shortcode('border_title', 'fun_bordertitle');
}

//Custom Theme quote...
if(!function_exists('fun_themequote')) {

	function fun_themequote($atts, $content = null) {
		extract(shortcode_atts(array(
			'animation' => '',
			'delay' => '300',
			'figure_url' => '',
			'title' => '',
			'subtitle' => ''
		), $atts));
		
		$out = '';
		
		$out .= '<li>';
			if($figure_url != NULL) {
				$out .= '<figure class="testimonial-thumb animate" data-animation="'.$animation.'" data-delay="'.$delay.'">';
					$out .= '<span class="item-mask"> </span>';
					$out .= '<img width="180" height="206" alt="testimonial-thumb" src="'.$figure_url.'" class="thumb-image">';
				$out .= '</figure>';
			}
			$out .= '<div class="testimonial-content-wrapper">';
				$out .= '<div class="author-meta">';
					if($title != NULL) $out .= '<p>'.$title.'</p>';
					if($subtitle != NULL) $out .= '<span>'.$subtitle.'</span>';
				$out .= '</div>';
				$out .= '<blockquote>'.do_shortcode($content).'</blockquote>';
			$out .= '</div>';
		$out .= '</li>';

		return $out;
	}
	add_shortcode('dt_quote', 'fun_themequote');
}

//Custom Theme testimonial...
if(!function_exists('fun_themetestimonial')) {

	function fun_themetestimonial($atts, $content = null) {
		
		$out = '';
		
		$out .= '<div class="testimonial-wrapper"><ul class="quotes_wrapper">'.do_shortcode($content).'</ul></div>';

		return $out;
	}
	add_shortcode('dt_testimonial', 'fun_themetestimonial');
}

//Custom Theme purchase demo button...
if(!function_exists('fun_btnpurchasedemo')) {

	function fun_btnpurchasedemo($atts, $content = null) {
		extract(shortcode_atts(array(
			'btn1_title' => '',
			'btn1_link' => '',
			'mid_text' => __('or', 'iamd_text_domain'),
			'btn2_title' => '',
			'btn2_link' => ''
		), $atts));
		
		
		$out = '';
		
		$out .= '<div class="demo-btn">';
			$out .= '<a class="purchase" href="'.$btn1_link.'">'.$btn1_title.'</a>';
				$out .= '<span>'.$mid_text.'</span>';
			$out .= '<a class="demo" href="'.$btn2_link.'">'.$btn2_title.'</a>';
		$out .= '</div>';

		return $out;
	}
	add_shortcode('double_button', 'fun_btnpurchasedemo');
}

//Custom Theme newsletter cointainer...
if(!function_exists('fun_newsletter_container')) {

	function fun_newsletter_container($atts, $content = null) {
		extract(shortcode_atts(array(
			'title' => '',
			'list_id' => ''
		), $atts));
		
		$out = '';
		
		$out .= '<div class="newsletter-container">';
			if($title != NULL) $out .= '<h2>'.$title.'</h2>';
			
			if($content != NULL) {
				$out .= '<div class="dt-sc-one-half column first">';
					$out .= '<p>'.do_shortcode($content).'</p>';
				$out .= '</div>';
			}			
			$out .= '<div class="dt-sc-one-half column last">';
				$out .= '<form method="post" action="'.get_template_directory_uri().'/php/subscribe.php" class="newsletter-form" name="frmnewsletter">';
					$out .= '<input type="email" name="mc_email" placeholder="Email Address" required>';
					$out .= '<input type="submit" name="btnsubscribe" class="dt-sc-button" value="subscribe">';
					$out .= '<input type="hidden" name="hid_apikey" value="'.mytheme_option('general','mailchimp-key').'">';
					$out .= '<input type="hidden" name="hid_listid" value="'.$list_id.'">';
				$out .= '</form>';
				$out .= '<div id="ajax_subscribe_msg"></div>';
			$out .= '</div>';
			
		$out .= '</div>';

		return $out;
	}
	add_shortcode('newsletter_container', 'fun_newsletter_container');
}

//Custom Theme button...
if(!function_exists('fun_themebutton')) {

	function fun_themebutton($atts, $content = null) {
		extract(shortcode_atts(array(
			'animation' => '',
			'delay' => '300',
			'size' => 'small', //small, medium, large
			'text' => __('Button', 'iamd_text_domain'),
			'arrow' => true,
			'link' => '#',
			'target' => 'self',
			'color' => ''
		), $atts));
		
		$out = '';
		$arrowT = '';
		if($arrow == true) {
			$arrowT = '<span class="icon-caret-right"></span>';
		}
		//Check it's animated or not..
		if($animation != NULL) {
			$out .= '<a href="'.$link.'" class="dt-sc-button '.$size.' animate" data-animation="'.$animation.'" data-delay="'.$delay.'" target="_'.$target.'">'.$text.$arrowT.'</a>';
		}
		else {
			$out .= '<a href="'.$link.'" class="dt-sc-button '.$size.' '.$color.'" target="_'.$target.'">'.$text.$arrowT.'</a>';			
		}
		
		return $out;
	}
	add_shortcode('theme_button', 'fun_themebutton');
}

//Custom Theme Contact Form...
if(!function_exists('fun_contactform')) {

	function fun_contactform($atts, $content = null) {
		extract(shortcode_atts(array(
			'submit_text' => __('Submit', 'iamd_text_domain'),
			'success_msg' => __('Thanks for Contacting Us, We will call back to you soon.', 'iamd_text_domain'),
			'error_msg' => __('Sorry your message not sent, Try again Later.', 'iamd_text_domain'),
			'subject' => __('Support', 'iamd_text_domain'),
			'admin_email' => get_bloginfo('admin_email')
		), $atts));
		
		$out = '';
		
		$out .= '<div id="ajax_contact_msg"></div>';
		$out .= '<form name="frmcontact" action="'.get_template_directory_uri().'/php/send.php" class="contact-frm" method="post">';

			$out .= '<div class="dt-sc-one-half column first">';		
				$out .= '<input type="text" required placeholder="'.__('Name', 'iamd_text_domain').'" name="txtname">';
				
				$out .= '<div class="dt-sc-one-half column first">';
					$out .= '<input type="email" required placeholder="'.__('Email', 'iamd_text_domain').'" name="txtemail">';
				$out .= '</div>';
				$out .= '<div class="dt-sc-one-half column">';
					$out .= '<input type="tel" placeholder="'.__('Phone', 'iamd_text_domain').'" name="txtphone">';
				$out .= '</div>';
			$out .= '</div>';
			
			$out .= '<div class="dt-sc-one-half column">';			
				$out .= '<textarea placeholder="'.__('Message', 'iamd_text_domain').'" name="txtmessage"></textarea>';
				$out .= '<input type="submit" class="dt-sc-button" value="'.$submit_text.'" name="btnsend">';				
			$out .= '</div>';

			$out .= '<input type="hidden" value="'.$admin_email.'" name="hidadmin_email">';
			$out .= '<input type="hidden" value="'.$subject.'" name="hidsubject">';
			$out .= '<input type="hidden" value="'.$success_msg.'" name="hidsuccess_msg">';
			$out .= '<input type="hidden" value="'.$error_msg.'" name="hiderror_msg">';
		$out .= '</form>';
		
		return $out;
	}
	add_shortcode('dt_contactform', 'fun_contactform');
}

//Custom Theme Location map...
if(!function_exists('fun_locationmap')) {

	function fun_locationmap($atts, $content = null) {
		extract(shortcode_atts(array(
			'map_title' => '',
			'address' => 'No: 58 A, East Madison St, Baltimore, MD, USA',
			'zoom' => '16',
			'phone' => '',
			'email1_title' => '',
			'email1' => '',
			'email2_title' => '',
			'email2' => '',
			'show_contactform' => false,
			'show_contactinfo' => false,
			'show_map' => false,
			'submit_text' => __('Submit', 'iamd_text_domain'),
			'success_msg' => __('Thanks for Contacting Us, We will call back to you soon.', 'iamd_text_domain'),
			'error_msg' => __('Sorry your message not sent, Try again Later.', 'iamd_text_domain'),
			'subject' => __('Support', 'iamd_text_domain'),
			'admin_email' => get_bloginfo('admin_email')
		), $atts));
		
		$out = '';
		$rndValue = substr(str_shuffle("abcdefghijklmnopqrstuvwxyz"), 0, 5);
		
		$out .= '<div class="location">';
			if($map_title != NULL) $out .= '<h4 class="map-title">'.$map_title.'</h4>';
			
			if($show_map == true) {
			
				$out .= '<div id="map_'.$rndValue.'" class="gmap" data-add="'.$address.'"></div>';
				$out .= '<div class="margin50"></div>';
			}
			
			$out .= '<div class="contact-info">';
			
				//Checking contact info true...
				if($show_contactinfo == true) {
					$out .= '<div class="dt-sc-one-half column first">';
						$out .= '<h4>'.__('Location', 'iamd_text_domain').'</h4>';
						$out .= '<p>'.$address.'<br>'.$phone.'</p>';
					$out .= '</div>';
					$out .= '<div class="dt-sc-one-half column">';
						$out .= '<div class="dt-sc-one-half column first">';
							if($email1_title != NULL) $out .= '<h4>'.$email1_title.'</h4>';
							if($email1 != NULL) $out .= '<a href="mailto:'.$email1.'">'.$email1.'</a>';
						$out .= '</div>';
						$out .= '<div class="dt-sc-one-half column">';
							if($email2_title != NULL) $out .= '<h4>'.$email2_title.'</h4>';
							if($email2 != NULL) $out .= '<a href="mailto:'.$email2.'">'.$email2.'</a>';
						$out .= '</div>';
					$out .= '</div>';
				}
				
				if($show_contactform == true) {
					$out .= '<div class="margin20"> </div>';							
					$out .= do_shortcode('[dt_contactform submit_text="'.$submit_text.'" success_msg="'.$success_msg.'" error_msg="'.$error_msg.'" subject="'.$subject.'" admin_email="'.$admin_email.'" /]');
				}
			$out .= '</div>';
		$out .= '</div>';
		
		return $out;
	}
	add_shortcode('location_map', 'fun_locationmap');	
}

//Custom Theme donut chart...
if(!function_exists('fun_progresschart')) {

	function fun_progresschart($atts, $content = null) {
		extract(shortcode_atts(array(
			'percentage' => 20,
			'percent_text' => __('Save', 'iamd_text_domain'),
			'bgcolor' => '#f5f5f5',
			'fgcolor' => '#E74D3C',
			'title' => '',
			'subtitle' => '',
			'button_text' => '',
			'button_link' => '',
			'button_size' => 'small',
			'button_color' => ''
		), $atts));
		
		$out = '';
		$rndValue = substr(str_shuffle("abcdefghijklmnopqrstuvwxyz"), 0, 3);
		
		$out .= '<div class="progress-bar-wrapper">';
			$out .= '<div id="donutchart_'.$rndValue.'" data-percent="'.$percentage.'" class="donutChart">'.$percent_text.'<br></div>';
			$out .= '<div class="progress-bar-content">';
				if($title != NULL) $out .= '<h4>'.$title.'</h4>';
				if($subtitle != NULL) $out .= '<span class="code">'.$subtitle.'</span>';
				if($content != NULL) $out .= '<p>'.do_shortcode($content).'</p>';
				if($button_text != NULL) $out .= '<a href="'.$button_link.'" class="dt-sc-button '.$button_size.' '.$button_color.'">'.$button_text.'<span class="icon-caret-right"></span></a>';
			$out .= '</div>';
		$out .= '</div>';
		
		//Donut script performing...
		$out .= "<script type='text/javascript'>\n";
			$out .= "\t(function($) {\n";
			$out .= "\t'use strict';\n";
			$out .= "\t$('#donutchart_".$rndValue."').one('inview', function (event, visible) {\n";
				$out .= "\t\t if(visible === true) {\n";
						$out .= "\t\t  $('#donutchart_".$rndValue."').donutchart({'size': 140, 'donutwidth': 10, 'fgColor': '".$fgcolor."', 'bgColor': '".$bgcolor."', 'textsize': 15 });\n";
						$out .= "\t\t  $('#donutchart_".$rndValue."').donutchart('animate');\n";
				$out .= "\t\t }\n";
			$out .= "\t});\n";
			$out .= "\t})(jQuery);\n";
		$out .= "</script>\n\n";
		
		return $out;
	}
	add_shortcode('progress_chart', 'fun_progresschart');		
}

//Custom Theme intro text...
if(!function_exists('fun_introtext')) {

	function fun_introtext($atts, $content = null) {
		
		$out = '';
		
		$out .= '<div class="intro-text"><div class="container">'.do_shortcode($content).'</div></div>';
		
		return $out;
	}
	add_shortcode('dt_intro_text', 'fun_introtext');
}

//Custom Theme intro text...
if(!function_exists('fun_dtcode')) {

	function fun_dtcode($attrs, $content=null){
		$array = array ('['=>'&#91;',']'=>'&#93;','/'=>'&#47;','<'=>'&#60;','>'=>'&#62;','<br />'=>'&nbsp;');
		$content = strtr($content, $array);
		$out = "<pre>{$content}</pre>";
		return $out;	
	}
	add_shortcode('code','fun_dtcode');
}

//FB LIKE...
add_shortcode('fblike','fblike');
function fblike( $attrs = null, $content = null,$shortcodename ="" ){
	extract(shortcode_atts(array('layout'=>'box_count','width'=>'','height'=>'','send'=>false,'show_faces'=>false,'action'=>'like','font'=> 'lucida+grande'
				,'colorscheme'=>'light'), $attrs));

	if ($layout == 'standard') { $width = '450'; $height = '35';  if ($show_faces == 'true') { $height = '80'; } }
	if ($layout == 'box_count') { $width = '55'; $height = '65'; }
	if ($layout == 'button_count') { $width = '90'; $height = '20'; }
	$layout = 'data-layout = "'.$layout.'" ';
	$width = 'data-width = "'.$width.'" ';
	$font = 'data-font = "'.str_replace("+", " ", $font).'" ';
	$colorscheme = 'data-colorscheme = "'.$colorscheme.'" ';
	$action = 'data-action = "'.$action.'" ';
	if ( $show_faces ) { $show_faces = 'data-show-faces = "true" '; } else { $show_faces = ''; }
	if ( $send ) { $send = 'data-send = "true" '; } else { $send = ''; }
	
    $out = '<div id="fb-root"></div><script>(function(d, s, id) {var js, fjs = d.getElementsByTagName(s)[0];if (d.getElementById(id)) return;js = d.createElement(s); js.id = id;js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";fjs.parentNode.insertBefore(js, fjs);}(document, "script", "facebook-jssdk"));</script>';
	$out .= '<div class = "fb-like" data-href = "'.get_permalink().'" '.$layout.$width.$font.$colorscheme.$action.$show_faces.$send.'></div>';
return $out;
}

//Google Plus...
add_shortcode('googleplusone','googleplusone');	
function googleplusone( $attrs = null, $content = null,$shortcodename ="" ){
	extract(shortcode_atts(array('size'=> '','lang'=> ''), $attrs));
	$size = empty($size) ? "size='small'" : "size='{$size}'";
	$lang = empty($lang) ? "{lang:en_GB}" : "{lang:'{$lang}'}";
	
	$out = '<script type="text/javascript" src="https://apis.google.com/js/plusone.js">'.$lang.'</script>';
	$out .= '<g:plusone '.$size.'></g:plusone>';
	return $out;
}

//Twitter Button...
add_shortcode('twitter','twitter');
function twitter( $attrs = null, $content = null,$shortcodename ="" ){
	extract(shortcode_atts(array('layout'=>'vertical','username'=>'','text'=>'','url'=>'','related'=> '','lang'=> ''), $attrs));
	
	$p_url= get_permalink();
	$p_title = get_the_title();
	
	$text = !empty($text) ? "data-text='{$text}'" :"data-text='{$p_title}'";
	$url = !empty($url) ? "data-url='{$url}'" :"data-url='{$p_url}'";
	$related = !empty($related) ? "data-related='{$related}'" :'';
	$lang = !empty($lang) ? "data-lang='{$lang}'" :'';
	$twitter_url = "http://twitter.com/share";
		$out = '<a href="{$twitter_url}" class="twitter-share-button" '.$url.' '.$lang.' '.$text.' '.$related.' data-count="'.$layout.'" data-via="'.$username.'">'.
	__('Tweet','iamd_text_domain').'</a>';
		$out .= '<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>';
	return $out;	
}

//Stumbleupon...
add_shortcode('stumbleupon','stumbleupon');
function stumbleupon( $attrs = null, $content = null,$shortcodename ="" ){
	extract(shortcode_atts(array('layout'=>'5','url'=>get_permalink()),$attrs));
	$url = "&r='{$url}'";
	$out = '<script src="http://www.stumbleupon.com/hostedbadge.php?s='.$layout.$url.'"></script>';
return $out;	
}

//LinkedIn...
add_shortcode('linkedin','linkedin');
function linkedin( $attrs = null, $content = null,$shortcodename ="" ){
	extract(shortcode_atts(array('layout'=>'2','url'=>get_permalink()),$attrs));
	
    	if ($url != '') { $url = "data-url='".$url."'"; }
	    if ($layout == '2') { $layout = 'right'; }
		if ($layout == '3') { $layout = 'top'; }
		$out = '<script type="text/javascript" src="http://platform.linkedin.com/in.js"></script><script type="in/share" data-counter = "'.$layout.'" '.$url.'></script>';
return $out;	
}

//Delicious...
add_shortcode('delicious','delicious');
function delicious( $attrs = null, $content = null,$shortcodename ="" ){
	extract(shortcode_atts(array('text'=>__("Delicious",'iamd_text_domain')),$attrs));
	
	$delicious_url = "http://www.delicious.com/save";
	
	$out = '<img src="http://www.delicious.com/static/img/delicious.small.gif" height="10" width="10" alt="Delicious" />&nbsp;<a href="{$delicious_url}" onclick="window.open(&#39;http://www.delicious.com/save?v=5&noui&jump=close&url=&#39;+encodeURIComponent(location.href)+&#39;&title=&#39;+encodeURIComponent(document.title), &#39;delicious&#39;,&#39;toolbar=no,width=550,height=550&#39;); return false;">'.$text.'</a>';
return $out;	
}

//Pinterest...
add_shortcode('pintrest','pintrest');
function pintrest( $attrs = null, $content = null,$shortcodename ="" ){
	extract(shortcode_atts(array('text'=>get_the_excerpt(),'layout'=>'horizontal','image'=>'','url'=>get_permalink(),'prompt'=>false),$attrs));
	$out = '<div class = "mysite_sociable"><a href="http://pinterest.com/pin/create/button/?url='.$url.'&media='.$image.'&description='.$text.'" class="pin-it-button" count-layout="'.$layout.'">'.__("Pin It",'iamd_text_domain').'</a>';
	$out .= '<script type="text/javascript" src="http://assets.pinterest.com/js/pinit.js"></script>';
	
	if($prompt):
		$out = '<a title="'.__('Pin It on Pinterest','iamd_text_domain').'" class="pin-it-button" href="javascript:void(0)">'.__("Pin It",'iamd_text_domain').'</a>';
		$out .= '<script type = "text/javascript">';
		$out .= 'jQuery(document).ready(function(){';
			$out .= 'jQuery(".pin-it-button").click(function(event) {';
			$out .= 'event.preventDefault();';
			$out .= 'jQuery.getScript("http://assets.pinterest.com/js/pinmarklet.js?r=" + Math.random()*99999999);';
			$out .= '});';
		$out .= '});';
		$out .= '</script>';
		$out .= '<style type = "text/css">a.pin-it-button {position: absolute;background: url(http://assets.pinterest.com/images/pinit6.png);font: 11px Arial, sans-serif;text-indent: -9999em;font-size: .01em;color: #CD1F1F;height: 20px;width: 43px;background-position: 0 -7px;}a.pin-it-button:hover {background-position: 0 -28px;}a.pin-it-button:active {background-position: 0 -49px;}</style>';
	
	endif;
	return $out;
}

//Digg...
add_shortcode('digg','digg');
function digg( $attrs = null, $content = null,$shortcodename ="" ){
	extract(shortcode_atts(array('layout'=>'DiggMedium','url'=>get_permalink(),'title'=>get_the_title(),'type'=>'','description'=>get_the_content(),'related'=>''),$attrs));
	

	
	if ($title != '') { $title = "&title='".$title."'"; }
	if ($type != '') { $type = "rev='".$type."'"; }
	if ($description != '') { $description = "<span style = 'display: none;'>".$description."</span>"; }
	if ($related != '') { $related = "&related=no"; }

	$out = '<a class="DiggThisButton '.$layout.'" href="http://digg.com/submit?url='.$url.$title.$related.'"'.$type.'>'.$description.'</a>';
	$out .= '<script type = "text/javascript" src = "http://widgets.digg.com/buttons.js"></script>';
	return $out;
}
?>