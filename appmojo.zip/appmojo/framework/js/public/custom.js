jQuery(document).ready(function ($) {

    "use strict";
    //CUSTOM SCROLL...
    if (typeof mytheme_urls !== 'undefined') {
        if (mytheme_urls.scroll == "enable") {
            $("html").niceScroll({
                zindex: 99999,
                cursorborder: "1px solid #424242"
            });
        }
    }

    //ONE PAGE NAV...
    $('#main-menu').onePageNav({
        currentClass: 'current-menu-item',
        filter: ':not(.external)',
        scrollSpeed: 750,
        scrollOffset: 90,
        scrollChange: fixMagicline
    });

    //MINI MOBILE MENU...
    $('nav#main-menu').meanmenu({
        meanMenuContainer: $('header #menu-container'),
        meanRevealPosition: 'left',
        meanScreenWidth: 797,
        meanMenuClose: "<span /><span /><span />"
    });

	//SUB MENU...
	$("#main-menu ul li:has(ul)").each(function(){
		$(this).addClass("hasSubmenu");
	});
	
	if ($.browser.safari || $.browser.msie) {
		$("#main-menu ul ul").css('display', 'none');
		$("#main-menu li.hasSubmenu").hover(function () {
			$(this).children("ul.sub-menu").css('display', 'block');
		}, function () {
			$(this).children("ul.sub-menu").css('display', 'none');
		});
	}	
	
    //TESTIMONIAL QUOTE...
    $('.quotes_wrapper').quovolver({
        children: 'li',
        transitionSpeed: 600,
        autoPlay: true,
        equalHeight: true,
        navPosition: 'below',
        navPrev: false,
        navNext: false,
        navNum: true
    });

    //ISOTOPE CATEGORY...
    var $container = $('.portfolio-container');
    var $gw;

    if ($('.portfolio-container .portfolio').hasClass('with-sidebar')) {
        if ($(".container").width() == 710 && ($('.portfolio-container .portfolio').hasClass('dt-sc-one-half') || $('.portfolio-container .portfolio').hasClass('dt-sc-one-fourth'))) {
            $gw = 10;
        } else {
            $gw = 14.5;
        }
    } else {
        if (($(".container").width() == 710 || $(".container").width() == 900) && ($('.portfolio-container .portfolio').hasClass('dt-sc-one-half') || $('.portfolio-container .portfolio').hasClass('dt-sc-one-fourth'))) {
            $gw = 15;
        } else {
            $gw = 20;
        }
    }

    $('.sorting-container a').click(function () {
        $('.sorting-container').find('a').removeClass('active-sort');
        $(this).addClass('active-sort');

        var selector = $(this).attr('data-filter');
        $container.isotope({
            filter: selector,
            animationOptions: {
                duration: 750,
                easing: 'linear',
                queue: false
            },
            masonry: {
                columnWidth: $('.portfolio-container .portfolio').width(),
                gutterWidth: $gw
            }
        });
        return false;
    });

    //ISOTOPE...
    if ($container.length) {
        $container.isotope({
            filter: '*',
            animationOptions: {
                duration: 750,
                easing: 'linear',
                queue: false
            },
            masonry: {
                columnWidth: $('.portfolio-container .portfolio').width(),
                gutterWidth: $gw
            }
        });
    }

    //UITOTOP...
    $().UItoTop({
        easingType: 'easeOutQuart'
    });

    //ISOTOPE...	
    var $pphoto = $('a[data-gal^="prettyPhoto[gallery]"]');
    if ($pphoto.length) {
        //PRETTYPHOTO...
        $("a[data-gal^='prettyPhoto[gallery]']").prettyPhoto({
            show_title: false,
            social_tools: false,
            deeplinking: false
        });
    }

    //MODERNIZER PLACE HOLDER...
    if (typeof Modernizr !== 'undefined') {
        if (!Modernizr.input.placeholder) {

            $('[placeholder]').focus(function () {
                var input = $(this);
                if (input.val() == input.attr('placeholder')) {
                    input.val('');
                    input.removeClass('placeholder');
                }
            }).blur(function () {
                var input = $(this);
                if (input.val() === '' || input.val() === input.attr('placeholder')) {
                    input.addClass('placeholder');
                    input.val(input.attr('placeholder'));
                }
            }).blur();

            $('[placeholder]').parents('form').submit(function () {
                $(this).find('[placeholder]').each(function () {
                    var input = $(this);
                    if (input.val() == input.attr('placeholder')) {
                        input.val('');
                    }
                });
            });
        }
    }

    //AJAX SUBMIT...
    $('form[name="frmnewsletter"]').submit(function () {

        var This = $(this);

        if ($(This).valid()) {
            var action = $(This).attr('action');

            var data_value = decodeURI($(This).serialize());
            $.ajax({
                type: "POST",
                url: action,
                data: data_value,
                error: function (xhr, status, error) {
                    confirm('The page save failed.');
                },
                success: function (response) {
                    $('#ajax_subscribe_msg').html(response);
                    $('#ajax_subscribe_msg').slideDown('slow');
                    if (response.match('success') !== null) $(This).slideUp('slow');
                }
            });
        }
        return false;
    });
    $('form[name="frmnewsletter"]').validate({
        rules: {
            mc_email: {
                required: true,
                email: true
            }
        },
        errorPlacement: function (error, element) {}
    });

    //CONTACT BOX VALIDATION & MAIL SENDING....
    $('form[name="frmcontact"]').submit(function () {

        var This = $(this);

        if ($(This).valid()) {
            var action = $(This).attr('action');

            var data_value = decodeURI($(This).serialize());
            $.ajax({
                type: "POST",
                url: action,
                data: data_value,
                error: function (xhr, status, error) {
                    confirm('The page save failed.');
                },
                success: function (response) {
                    $('#ajax_contact_msg').html(response);
                    $('#ajax_contact_msg').slideDown('slow');
                    if (response.match('success') !== null) $(This).slideUp('slow');
                }
            });
        }
        return false;
    });
    $('form[name="frmcontact"]').validate({
        rules: {
            txtname: {
                required: true
            },
            txtemail: {
                required: true,
                email: true
            }
        },
        errorPlacement: function (error, element) {}
    });

    //PORTFOLIO CarouFredSel...
    if ($('.portfolio-slider').length) {
        $('.portfolio-slider').carouFredSel({
            responsive: true,
            width: '100%',
            scroll: {
                fx: "crossfade"
            },
            prev: '.portfolio-arrows .prev',
            next: '.portfolio-arrows .next',
            auto: false,
            items: 1
        });
    }

    //GOOGLE MAP...
    if ($('.gmap').length) {
        $('.gmap').each(function () {
            var $addr = $(this).attr('data-add');
            $(this).gMap({
                address: $addr,
                zoom: 16,
                markers: [{
                    'address': $addr
                }]
            });
        });
    }	
});

//CUSTOM FIX...
function fixMagicline() {
    "use strict";
    var $magicLine = jQuery("#magic-line");

    var leftPos, newWidth;

    leftPos = jQuery(".current-menu-item a").position().left;
    newWidth = jQuery(".current-menu-item").width();

    $magicLine.stop().animate({
        left: leftPos,
        width: newWidth
    });
}

// animate css + jquery inview configuration
(function ($) {
    "use strict";
    $(".animate").each(function () {
        $(this).bind('inview', function (event, visible) {
            var $delay = "";
            var $this = $(this),
                $animation = ($this.data("animation") !== undefined) ? $this.data("animation") : "slideUp";
            $delay = ($this.data("delay") !== undefined) ? $this.data("delay") : 300;

            if (visible === true) {
                setTimeout(function () {
                    $this.addClass($animation);
                }, $delay);
            } else {
                setTimeout(function () {
                    $this.removeClass($animation);
                }, $delay);
            }
        });
    });

})(jQuery);

function funtoScroll(x, e) {
    "use strict";
	var et = String(e.target);
	var pos = et.indexOf('#');
    var t = et.substr(pos);
	
	if(jQuery('#main-menu .group li.current-menu-item a').hasClass('external')) {
		window.location.href = et;
	}
	else {
	    jQuery.scrollTo(t, 750);
	}

    jQuery(x).parent('.mean-bar').next('.mean-push').remove();
    jQuery(x).parent('.mean-bar').remove();

    jQuery('nav#main-menu').meanmenu({
        meanMenuContainer: jQuery('header #menu-container'),
        meanRevealPosition: 'left',
        meanScreenWidth: 767,
        meanMenuClose: "<span /><span /><span />"
    });

    e.preventDefault();
}