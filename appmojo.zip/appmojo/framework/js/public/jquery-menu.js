// DOM Ready
jQuery(function ($) {
    "use strict";
    var $el, $gp, leftPos, newWidth, mystr;

    /* Add Magic Line markup via JavaScript, because it ain't gonna work without */
    $("#main-menu ul.group").append("<li id='magic-line'></li>");

    /* Cache it */
    var $magicLine = $("#magic-line");

    if ($('ul.group li').hasClass('current-menu-parent')) {
		mystr = ".current-menu-parent";
    }
	else if(!$('ul.group li').hasClass('current-menu-item')) {
		$('ul.group li:first').addClass('current-menu-item');
		mystr = ".current-menu-item";
	}
	else {
		mystr = ".current-menu-item";
	}
	
	$magicLine
		.width($(mystr).width())
		.css("left", $(mystr+" a").position().left)
		.data("origLeft", $magicLine.position().left)
		.data("origWidth", $magicLine.width());

    $("#main-menu ul li").find("a").hover(function () {
		$el = $(this);
		$gp = $(this).parent().parent('ul');
		if($gp.hasClass('sub-menu')) {
			leftPos  = $gp.prev('a').position().left;
			newWidth = $gp.prev('a').parent().width();				
		} else {
			leftPos = $el.position().left;
			newWidth = $el.parent().width();
		}
		$magicLine.stop().animate({
			left: leftPos,
			width: newWidth
		});		
    }, function () {
        //Hover stop checks...
        var x = '.current-menu-item a';
		
		if($gp.hasClass('sub-menu')) {
			x = $gp.prev('a');
		}		
        if (!$('ul.group li').hasClass('current-menu-item')) {
            x = this;
        }
        $magicLine.stop().animate({
            left: $(x).position().left,
            width: $(x).parent().width()
        });
    });

});