<!-- #home -->
<div id="home" class="bpanel-content">
  <!-- .bpanel-main-content -->
    <div class="bpanel-main-content">
        <ul class="sub-panel">
            <li><a href="#my-home"><?php _e("Home",'iamd_text_domain');?></a></li>        
        </ul>
        
        <!-- #my-responsive start --> 
        <div id="my-home" class="tab-content">
        	<div class="bpanel-box">
                
                <div class="box-title"><h3><?php _e('Slider','iamd_text_domain');?></h3></div>
                <div class="box-content">
                	<h6><?php _e('Enable Home Page Slider', 'iamd_text_domain');?></h6>
                    	<?php $switchclass = ("on" == mytheme_option('home', 'slider-section')) ? 'home-slider-checked-switch-on checkbox-switch-on' : 'home-slider-checked-switch-off checkbox-switch-off'; ?>
                    	<div data-for="mytheme-home-slider-section" class="home-section-switcher checkbox-switch <?php echo $switchclass;?>"></div>
                    	<input class="hidden" id="mytheme-home-slider-section" name="mytheme[home][slider-section]" type="checkbox" <?php checked(mytheme_option('home','slider-section'),'on');?>/>
                        <p class="note"> <?php _e('Enable or Disable Home page slider.','iamd_text_domain');?>  </p>
                        
                     <div class="hr"></div><?php $show_home_slider_section = ("on" == mytheme_option('home', 'slider-section') ) ? " style='display:block;' " : "  style='display:none;' "; ?>
                     
                     <div class="top-section-slider column one-column bpanel-option-set" <?php echo $show_home_slider_section;?>>
                        <label><?php _e('Select Slider','iamd_text_domain');?></label>
                        <div class="clear"></div>
                        
                        <select class="slider-type" name="mytheme[home][slider]"><?php
							$slider_types = array( 
								'' => __("No Slider",'iamd_text_domain'),
								'layerslider' => __("Layer Slider",'iamd_text_domain'),
								'revolutionslider' => __("Revolution Responsive",'iamd_text_domain'));
								
							$v = mytheme_option('home','slider'); 
							foreach($slider_types as $key => $value):
								$rs = selected($key,$v,false);
								echo "<option value='{$key}' {$rs}>{$value}</option>";
							endforeach;?></select>
                        <p class="note"> <?php _e("Choose which slider you wish to use ( eg: Layer or Revolution )",'iamd_text_domain');?> </p>    
                        <div class="hr-invisible"></div>
                        <div class="hr-invisible"></div>
                        
                        <!-- slier-container starts-->
                        <div id="slider-conainer"><?php
							$layerslider = $revolutionslider = 'style="display:none"';
							$type = mytheme_option('home','slider');
							if($type === "layerslider"):
								$layerslider = 'style="display:block"';
							elseif($type === "revolutionslider"):
								$revolutionslider = 'style="display:block"';
							endif;?>
                            
                            <!-- Layered Slider -->
                            <div id="layerslider" <?php echo $layerslider;?>>
                            <label><?php _e('Layer Slider','iamd_text_domain');?></label>
                            <?php if(mytheme_is_plugin_active('LayerSlider/layerslider.php')): ?>
                            		<div class="clear"></div><?php global $wpdb;
										$table_name = $wpdb->prefix . "layerslider";
										$sliders = $wpdb->get_results( "SELECT * FROM $table_name WHERE flag_hidden = '0' AND flag_deleted = '0'  ORDER BY date_c ASC LIMIT 100" );
										
										if($sliders != null && !empty($sliders)):
											$out  = '<select name="mytheme[home][layerslider_id]">';
											$out .= '<option value="0">'.__("Select Slider",'iamd_text_domain').'</option>';
											foreach($sliders as $item) :
												$name = empty($item->name) ? 'Unnamed' : $item->name;
												$id = $item->id;
												$rs = mytheme_option('home','layerslider_id'); 
												$rs = selected($id,$rs,false);
												$out .="<option value='{$id}' {$rs}>{$name}</option>";
											endforeach;
											$out .= '</select>';
											echo $out;
										else:
											echo '<p id="j-no-images-container">'.__('Please add atleat one layer slider','core').'</p>';
										endif;
							  	    else:
										echo '<p id="j-no-images-container">'.__('Please activate Layered Slider','core').'</p>';
									endif;?></div><!-- Layered Slider -->
                            
                            <!-- Revolution Slider -->
                            <div id="revolutionslider" <?php echo $revolutionslider;?>>
                            	<label><?php _e('Revolution Slider','core');?></label>
                                <div class="clear"></div><?php
									$return = check_slider_revolution_responsive_wordpress_plugin();
									if($return): 
										$out  = '<select name="mytheme[home][revolutionslider_id]">';
										$out .= '<option value="0">'.__("Select Slider",'iamd_text_domain').'</option>';
										foreach($return as $key => $value):
											$rs = mytheme_option('home','revolutionslider_id'); 
											$rs = selected($key,$rs,false);
											$out .= "<option value='{$key}' {$rs}>{$value}</option>";
										endforeach;
										$out .= '</select>';
										echo $out;
									else:
										echo '<p id="j-no-images-container">'.__('Please activate Revolution Slider , and add at least one slider.','core').'</p>';
									endif;
							?></div><!-- Revolution Slider -->
                            
                        </div><!-- slier-container ends-->
                        
                     </div><!-- .top-sectoin-slider -->
                     
                </div>
            
            </div>
        </div><!-- #my-home end -->
        
     </div><!-- .bpanel-main-content end-->   
</div><!-- #home end -->