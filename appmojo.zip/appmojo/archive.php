<?php get_header();

	  $page_layout = mytheme_option('specialty', 'archives-layout'); ?>
	
	  <div class="banner"></div>
      <!-- Page Section Starts here -->
      <section id="post-<?php the_ID(); ?>" <?php post_class('content inner-page'); ?>>
	      <?php if(!is_front_page() and !is_home()): ?>
              <div class="main-title">
                  <div class="container">
                      <h1><?php
                      	if(is_category()): _e('Category Archives of : ', 'iamd_text_domain'); echo single_cat_title();
						elseif(is_day()):  _e('Daily Archives of : ', 'iamd_text_domain'); echo get_the_date('l');
						elseif(is_month()):  _e('Monthly Archives of : ', 'iamd_text_domain'); echo get_the_date('F, Y');
						elseif(is_year()):  _e('Yearly Archives of : ', 'iamd_text_domain'); echo get_the_date('Y');
						elseif(is_author()):  _e('Archive by Author : ', 'iamd_text_domain'); $author = get_user_by('login', get_query_var('author_name')); echo $author->nickname;
						elseif(is_tag()):  _e('Tag Archives of : ', 'iamd_text_domain'); echo single_tag_title('', true);
						elseif(taxonomy_exists('category')):  _e('Archive of : ', 'iamd_text_domain'); echo single_cat_title();			  
						endif; ?></h1>
                  </div>
              </div>
		  <?php endif; ?>              
          <div class="content-main">                
              <div class="container">
              
                  <!-- Primary -->
                  <div id="primary" class="<?php echo $page_layout; ?>"><?php
					  get_template_part('includes/archive-blog-post'); ?>
                  </div><!-- Primary -->
                  
                  <!-- Secondary -->
				  <?php if($page_layout != 'content-full-width' && $page_layout == 'with-left-sidebar'): ?>
                      <div id="secondary" class="left-sidebar"><?php get_sidebar(); ?></div>
                  <?php elseif($page_layout != 'content-full-width' && $page_layout == 'with-right-sidebar'): ?>    
                      <div id="secondary"><?php get_sidebar(); ?></div>
                  <?php endif; ?><!-- Secondary -->
              
              </div>                                
          </div>
      </section><!-- Page Section Ends here -->
      
<?php get_footer(); ?>