<?php
	//SIDEBAR FOLLOWS...
	wp_reset_query();
	global $post;
	  
	if(is_page() || ( is_single() and 'post'== get_post_type())):
	  
		$tpl_default_settings = get_post_meta($post->ID,'_tpl_default_settings',TRUE);
		$tpl_default_settings = is_array($tpl_default_settings) ? $tpl_default_settings  : array();
		
		if (!array_key_exists("disable-everywhere-sidebar",$tpl_default_settings)):
			if(function_exists('dynamic_sidebar') && dynamic_sidebar(('display-everywhere-sidebar'))): endif;
		endif;
		
	else:
	 
		if(function_exists('dynamic_sidebar') && dynamic_sidebar(('display-everywhere-sidebar'))): endif;
		
	endif;	  
	  
	if(is_page()):
	  
		if(function_exists('dynamic_sidebar') && dynamic_sidebar(('page-'.get_the_ID().'-sidebar'))):  endif;
		
	elseif(is_single() and 'post' == get_post_type()):
	  
		if(function_exists('dynamic_sidebar') && dynamic_sidebar(('post-'.get_the_ID().'-sidebar'))):  endif;
		
	elseif(is_category()):
	  
	  	if(function_exists('dynamic_sidebar') && dynamic_sidebar(('category-'.get_query_var('cat').'-sidebar'))):  endif;
		
	endif; ?>