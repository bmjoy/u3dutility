<?php
// Do not delete these lines
if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
die ('Please do not load this page directly. Thanks!');
 
if ( post_password_required() ) { ?>
	<p class="nocomments">This post is password protected. Enter the password to view comments.</p>
<?php 
	return;
}
?>
<!-- START EDITING HERE. -->

<div class="hr"> </div>
<!-- **Comment Entries** -->   	
<div class="commententries" id="comments">

	<?php if(have_comments()):    
			if(get_comment_pages_count() > 1 && get_option('page_comments')): ?>
                <div class="pagination">
                    <ul class="commentNav">
                        <li><?php previous_comments_link(); ?></li>
                        <li><?php next_comments_link(); ?></li>
                    </ul>
                </div><?php
            endif; ?>
            
            <h4><?php comments_number(__('No Comments', 'iamd_text_domain'), __('Comment (1)', 'iamd_text_domain'), __('Comments (%)', 'iamd_text_domain')); ?></h4>
			<ul class="commentlist">
	            <?php wp_list_comments('avatar_size=88&type=comment&callback=mytheme_custom_comments&style=ul'); ?>
            </ul>
            
	<?php else:
			if('open' == $post->comment_status): ?>
				<h4><?php _e('No Comments', 'iamd_text_domain'); ?></h4><?php
			endif;
		  endif; ?>

</div><!-- **Comment Entries - End** -->

<?php if('open' == $post->comment_status):
		$args = array(
			'comment_field' => '<div class="clear"> </div><textarea id="comment" name="comment" rows="3" cols="5" placeholder="Your Message (required)"></textarea>',		
			'fields' => array(
					'author' => '<div class="column dt-sc-one-half first"><input id="author" name="author" type="text" placeholder="Your Name (required)" /></div>',
					'email' => '<div class="column dt-sc-one-half"><input id="email" name="email" type="text" placeholder="Your Email (required)" /></div>',
					'url' => '<input id="url" name="url" type="text" placeholder="Your Website (optional)" />',),
			'comment_notes_before' => '',
			'label_submit' => __('Post comment', 'iamd_text_domain'),
			'comment_notes_after' => '',
			'title_reply' => __('Post a comment', 'iamd_text_domain'),
			'cancel_reply_link' => 'cancel reply'
		);
		comment_form($args);
	  endif; ?>