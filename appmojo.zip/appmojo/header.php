<!DOCTYPE html>
<!--[if lt IE 7]>  <html class="ie ie6 lte9 lte8 lte7" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 7]>     <html class="ie ie7 lte9 lte8 lte7" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 8]>     <html class="ie ie8 lte9 lte8" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 9]>     <html class="ie ie9 lte9" <?php language_attributes(); ?>> <![endif]-->
<!--[if gt IE 9]>  <html> <![endif]-->
<!--[if !IE]><!--> <html <?php language_attributes(); ?>> <!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />    
	<?php is_mytheme_moible_view(); ?>
	<meta name="description" content="<?php bloginfo('description'); ?>"/>
	<meta name="author" content="designthemes"/>
    
    <!--[if lt IE 9]> 
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
	
	<title><?php mytheme_public_title(); ?></title>

	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<?php
	//LOAD THEME STYLES...
	mytheme_front_css();
	if(mytheme_option('integration', 'enable-header-code') != '') echo stripslashes(mytheme_option('integration', 'header-code'));	
	wp_head(); ?>
    
<body <?php if(mytheme_option("appearance","layout") == "boxed") body_class('boxed'); else body_class(); ?>>
	<div class="wrapper">
		<div class="inner-wrapper">
			<!-- Header div Starts here -->
            <header id="header">
                <div class="container">
                    <div id="logo">
						<?php if(mytheme_option('general', 'logo') == true and mytheme_option('general', 'logo-url') != ""): ?>
							<a href="<?php echo home_url(); ?>" title="<?php bloginfo('title'); ?>"><img src="<?php echo mytheme_option('general', 'logo-url'); ?>" alt="<?php bloginfo('title'); ?>" title="<?php bloginfo('title'); ?>" /></a>                           
                        <?php elseif(mytheme_option('general', 'logo') == true and mytheme_option('general', 'logo-url') == ""): ?>
                            <a href="<?php echo home_url(); ?>" title="<?php bloginfo('title'); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="<?php bloginfo('title'); ?>" title="<?php bloginfo('title'); ?>" /></a>
                        <?php else: ?>
                            <div class="logo-title"><h1 id="site-title"><a href="<?php echo home_url(); ?>" title="<?php bloginfo('title'); ?>"><?php bloginfo('title'); ?></a></h1><h2 id="site-description"><?php bloginfo('description'); ?></h2></div>
                        <?php endif; ?>
                    </div>
                    <div id="menu-container">
                        <nav id="main-menu">
	                        <?php wp_nav_menu( array('theme_location' => 'header_menu', 'container'  => false, 'menu_class' => 'group', 'fallback_cb' => 'mytheme_default_navigation', 'walker' => new dt_menu_walker())); ?>
                        </nav>
                    </div>                    
                </div>
            </header>
            <!-- Header div Ends here -->
    		
            <!-- Main div Starts here -->    
	        <div id="main">        