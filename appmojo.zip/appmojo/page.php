<?php get_header();

	while(have_posts()): the_post();
	
      if(is_page()) mytheme_slider_section($post->ID);
	  
	  //GETTING META VALUES...
	  $meta_set = get_post_meta($post->ID, '_tpl_default_settings', true);
	  $page_layout = !empty($meta_set['layout']) ? $meta_set['layout'] : 'content-full-width'; ?>
	
      <!-- Page Section Starts here -->
      <section id="post-<?php the_ID(); ?>" <?php post_class('content inner-page'); ?>>
          <?php if(!is_front_page() and !is_home()): ?>
              <div class="main-title">
                  <div class="container">
                      <h1><?php the_title(); ?></h1>
                  </div>
              </div>
          <?php endif; ?>
          <div class="content-main">                
              <div class="container">
              
                  <!-- Primary -->
                  <div id="primary" class="<?php echo $page_layout; ?>"><?php
						  //PAGE TOP CODE...
						  if(mytheme_option('integration', 'enable-single-page-top-code') != '') echo stripslashes(mytheme_option('integration', 'single-page-top-code'));
						  
                          if(has_post_thumbnail()):
						  	  $feature_image = 'custom-thumb';
							  if($page_layout != 'content-full-width') $feature_image = 'custom-thumb'.'-sidebar'; ?>
                              <div class="post-thumb">
                                  <?php $attr = array('title' => get_the_title()); the_post_thumbnail($feature_image, $attr); ?>
                              </div>
							  <div class="margin25"></div><?php
						  endif; ?>
                          
                          <div class="entry-details"><?php
							  the_content();
							  wp_link_pages(array('before' => '<div class="page-link"><strong>'.__('Pages:', 'iamd_text_domain').'</strong> ', 'after' => '</div>', 'next_or_number' => 'number'));
							  edit_post_link(__('Edit', 'iamd_text_domain'), '<span class="edit-link">', '</span>' );
							  echo '<div class="social-bookmark">';
								show_fblike('page'); show_googleplus('page'); show_twitter('page'); show_stumbleupon('page'); show_linkedin('page'); show_delicious('page'); show_pintrest('page'); show_digg('page');
							  echo '</div>';
							  mytheme_social_bookmarks('sb-page');
							  if(mytheme_option('integration', 'enable-single-page-bottom-code') != '') echo stripslashes(mytheme_option('integration', 'single-page-bottom-code')); ?>
                          </div>
                          
	                      <?php if(mytheme_option('general', 'disable-page-comment') != true && (isset($meta_set['comment']) != "")) comments_template('', true); ?>
                  </div><!-- Primary -->
                  
                  <!-- Secondary -->
				  <?php if($page_layout != 'content-full-width' && $page_layout == 'with-left-sidebar'): ?>
                      <div id="secondary" class="left-sidebar"><?php get_sidebar(); ?></div>
                  <?php elseif($page_layout != 'content-full-width' && $page_layout == 'with-right-sidebar'): ?>    
                      <div id="secondary"><?php get_sidebar(); ?></div>
                  <?php endif; ?><!-- Secondary -->
              
              </div>                                
          </div>
      </section><!-- Page Section Ends here -->
      
	<?php endwhile; ?>      

<?php get_footer(); ?>